print(eval('+'.join('*'.join(str(x)) for x in range(10, 1001))))

print("*".join("10"))
print(eval("*".join("10")))
print('*'.join(str(x)) for x in range(10, 1001))

