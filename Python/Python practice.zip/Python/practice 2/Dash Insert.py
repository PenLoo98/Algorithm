#  https://codingdojang.com/scode/529

# 홀수 연속시 "-"
# 짝수 연속시 "*"

input_num = "4546793"

입력된 문자열 각 자릿수를 for문으로 꺼낸다
꺼낸 숫자의 홀짝을 확인한다


for num in input_num:
    bef
    if int(num)%2 == 1:

    if int(num)%2 == 0:
    aft