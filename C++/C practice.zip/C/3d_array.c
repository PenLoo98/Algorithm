#include <stdio.h>

int main(){
    int array3D[2][3][4];
    int m,c,l, value=0;

    for (m=0; m<2; m++){
        for (c=0; c<3; c++){
            for (l=0; l<4; l++){
                array3D[m][c][l] = value;
                printf("array3D[%d][%d][%d] = %d \n", m, c, l, array3D[m][c][l]);
                value++;
            }
        }
    }
    
}