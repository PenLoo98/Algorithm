#include <stdio.h>

int main(){
    int a = 10;
    int *ptr;
    ptr = &a;
    *ptr = 12;
    
    printf("a: %d\n", a);
    printf("&a: %d\n", &a);
    printf("ptr: %d\n", ptr);
    printf("*ptr: %d\n", *ptr);

    return 0;
}