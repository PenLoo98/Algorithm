#include <stdio.h>
#include <stdlib.h>
#define MAX 10

int insertElement(int L[], int n, int x){
    int i,k = 0, move = 0;
    
    // x가 들어갈 위치를 찾는다.
    for (i = 0; i < n; i++){
        if (L[i] < x && x <= L[i+1]){
            k = i+1;
            break;
        }
    }
    // x가 리스트의 가장 큰 원소일 경우
    if (i == n)
        k = n;
    
    // k+1부터 마지막 원소까지 뒤로 자리이동
    for (i = n; i > k; i--){
        L[i] = L[i-1];
        move++;
    }
    // x를 리스트에 삽입
    L[k] = x;
    return move;

}


int deleteElement(int L[], int n, int x){
    int i,k = 0, move = 0;
    
    // x가 리스트에 있는지 확인
    for (i = 0; i < n; i++){
        if (L[i] == x){
            k = i;
            break;
        }
    }
    // x가 리스트에 없을 경우
    if (i == n)
        move = n;
    
    // k+1 부터 마지막 원소까지 앞으로 자리이동 
    for (i = k; i < n-1; i++){
        L[i] = L[i+1];
        move++;
    }
    return move;

}

int main(void) {
    int list[MAX] = {1, 3, 5, 7, 9};
    int i, move, size = 6;
    // size는 리스트의 원소의 갯수
    printf("Before insert: ");
    for(i=0; i<size; i++)
        printf("%d ", list[i]);
    printf("\n원소의 갯수: %d\n", size);

    move = insertElement(list, size, 4);

    printf("After insert: ");
    for(i=0; i<size; i++)
        printf("%d ", list[i]);
    printf("\n원소의 갯수: %d\n", size);
    printf("이동횟수: %d\n", move);

    move = deleteElement(list, size, 4);
    if (move == size)
        printf("삭제할 원소가 없습니다.\n");
    else{
        printf("After delete: ");
        for(i=0; i<size-1; i++)
            printf("%d ", list[i]);
        printf("\n원소의 갯수: %d\n", size-1);
        printf("이동횟수: %d\n", move);
    }

    getchar();
    return 0;
}