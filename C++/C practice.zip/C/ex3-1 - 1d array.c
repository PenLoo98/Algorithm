#include <stdio.h>

int main(void){
    int i, listA[4] = {1, 2, 3, 4};

    // Print the address and value of each element in listA
    // int size = 4bytes
    for(i=0;i<4;i++){
        printf("listA Address: %u, Value: %d \n", &listA[i], listA[i]);
    }
}