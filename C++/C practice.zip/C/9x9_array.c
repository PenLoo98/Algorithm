#include <stdio.h>

int main(){
    int n;

    printf("input a number in : ");
    scanf("%d", &n);

    int i;
    for (i=1; i<=9; i++){
        printf("%d x %d = %d \n", n, i, n*i);
    }

    return 0;
}