#include <stdio.h>
#include <stdlib.h>

int *queue;
int front = 0; // initialize front as 0
int rear = 0;
int size = 10;
//QUEUE_SIZE => size   

int isEmpty() {
    if (front == rear) return 1;
    else return 0;
}

int isFull() {
    if ((rear + 1) % size == front) return 1;
    else return 0;
}

int queueSize() {
    return (rear - front + size) % size;
}

void enqueue(int item) {
    if (isFull()) {
        // dynamically allocate memory for queue
        int *temp = (int*)malloc(size * 2 * sizeof(int)); // double the size of queue
        int i, j;
        for (i = front + 1, j = 0; i <= rear; i++, j++) {
            temp[j] = queue[i % size]; // copy existing elements to new queue
        }
        front = -1;
        rear = j - 1;
        size *= 2;
        free(queue);
        queue = temp;
    }
    rear = (rear + 1) % size;
    queue[rear] = item;
}

int dequeue() {
    if (isEmpty()) {
        printf("\n\n Queue is Empty!!\n");
        return 0;
    }
    else {
        front = (front + 1) % size;
        return queue[front];
    }
}

void printQueue() {
    int i, maxi = rear;
    if (front >= rear) maxi += size;
    printf("Queue size is [%2d] = ", queueSize());
    for (i = front + 1; i <= maxi; i++)
        printf("%2d ", queue[i % size]);
    printf("\n");
}

int main(void) {
    int i;
    queue = (int*)malloc(size * sizeof(int));

    for (i = 0; i < 9; i++) enqueue(i + 1);
    printQueue();
    for (i = 0; i < 7; i++) dequeue();
    printQueue();
    for (i = 10; i < 19; i++) enqueue(i + 1);
    printQueue();

    free(queue);
    getchar();
}
