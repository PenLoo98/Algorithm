#include <stdio.h>

int main()
{
    int a[5] = {1, 2, 3, 4, 5};
    int i;
    for (i = 0; i < 5; i++)
    {
        printf("a[%d]=%d\n",i,a[i]);
    }
    printf("\n");

		// 배열크기보다 조금 할당한 경우
    int b[5] = {1, 2, 3};
    int j;
    for (j=0; j<5; j++)
    {
        printf("b[%d]=%d \n",j,b[j]);
        
    }
    printf("\n");
		
		// 배열크기보다 많이 할당한 경우
    int c[5] = {1,2,3,4,5,6,7,8,9,10};
    int k;
    for (k=0; k<10; k++)
    {
        printf("c[%d]=%d \n",k,c[k]);
    }
    printf("\n c: %d \0",c);

    return 0;
}