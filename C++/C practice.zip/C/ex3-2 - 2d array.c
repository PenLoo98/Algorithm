#include <stdio.h>

int main(void){
    int i,j, listA[4][10];
    int value;

    // Print the address and value of each element in listA
    // int size = 4bytes
    for(i=0;i<4;i++){
        for(j=0;j<10;j++){
            listA [i][j] = value;
            printf("listA[%d][%d] Address: %u, Value: %d \n",i,j,&listA[i][j], listA[i][j]);
            value++;
        }
    }
}