#include <stdio.h>
#include <stdlib.h>

#define STACK_SIZE 10

int *stack;
int top = -1;	// top 초기화
int size = 1;	// size 초기화

int isEmpty() {
	if (top == -1) return 1;
	else return 0;
}

int isFull() {
	if (top % STACK_SIZE == 9) return 1;
	else return 0;
}

// 스택의 top에 원소를 삽입하는 연산 == append()
void append(int item) {
	int *temp;

	if (isFull()) {
		printf(" Full STACK\n");
		temp = (int*)malloc((STACK_SIZE * size)* sizeof(int));

		for (int i = 0; i < (top + 1); i++) temp[i] = stack[i];
		stack = (int*)malloc((STACK_SIZE * (size + 1))* sizeof(int));

		for (int i = 0; i < (top + 1); i++) stack[i] = temp[i];
		stack[++top] = item;  // top을 증가시킨 후 현재 top에 원소 삽입

		size++;

		free(temp);

	}
	else stack[++top] = item;  // top을 증가시킨 후 현재 top에 원소 삽입
}

// 스택의 pos에 원소를 삽입하는 연산 == insert()
void insert(int pos, int item) {
	int *temp;

	if (isFull()) {
		printf(" Full STACK\n");
		temp = (int*)malloc((STACK_SIZE * size)* sizeof(int));

		for (int i = 0; i < (top + 1); i++) temp[i] = stack[i];
		stack = (int*)malloc((STACK_SIZE * (size + 1))* sizeof(int));

		for (int i = 0; i < (top + 1); i++) stack[i] = temp[i];
		stack[++top] = item;  // top을 증가시킨 후 현재 top에 원소 삽입

		size++;

		free(temp);

	}
	else {
		for (int i = top; i > pos; i--) stack[i] = stack[i - 1];
		stack[pos] = item;  // 현재 top에 원소 삽입 후 top을 증가시킴
		top++;
	}
}

// 스택의 pos에 있는 원소를 삭제하는 연산 == pop()
int pop(int pos) {
	if (isEmpty()) {
		printf(" Empty STACK\n");
		return -1;
	}
    if (pos < 0 || pos > top) {
        printf(" Invalid position\n");
        return -1;
    }
	int value = stack[pos];
    for (int i = pos; i < top; i++) {
        stack[i] = stack[i+1];
    }
    top--;
    return value;
}

// 스택의 원소를 출력하는 연산
void printStack() {
	int i;
	printf("STACK SIZE [%d]\n", (STACK_SIZE * size));
	printf("STACK [ ");
	for (i = 0; i <= top; i++) printf("%d ", stack[i]);
	printf("]\n\n");
}

int main(void) {
    stack = (int*)malloc(STACK_SIZE * sizeof(int));
    
	int i;
    for (i = 0; i < 30; i++) append(i + 1);
    printStack();	

	printf(" POP index 0 - Data [%d]\n", pop(0));
    printStack();
	printf(" POP index 2 - Data [%d]\n", pop(2));
    printStack();
	printf(" POP index 4 - Data [%d]\n", pop(4));
    printStack();

	printf(" INSERT index 0 - Data [100]\n");
	insert(0, 1000);
	printStack();
	printf(" INSERT index 5 - Data [200]\n");
	insert(5, 2000);
	printStack();
	printf(" INSERT index 10 - Data [300]\n");
	insert(10, 3000);
	printStack();

    free(stack);
    getchar();
}