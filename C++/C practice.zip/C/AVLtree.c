#include <stdio.h>

typedef int element;

typedef struct TreeNode{
    element key;
    struct TreeNode *left, *right;
} TreeNode;

void displayInOrder(TreeNode* root);

TreeNode* searchBST(TreeNode* root, element x);
TreeNode* insertBST(TreeNode* p, element x);
void deleteNode(TreeNode* root, element key);

TreeNode* RRrotation(TreeNode* parent);
TreeNode* LLrotation(TreeNode* parent); 
TreeNode* LRrotation(TreeNode* parent);
TreeNode* RLrotation(TreeNode* parent);

int getHeight(TreeNode* p);
int getBF(TreeNode* p);
TreeNode* rebalance(TreeNode** p);
TreeNode* insertAVLnode(TreeNode** root, element x);

int main(){
    TreeNode* rootAVL = NULL;
    TreeNode* rootBST = NULL;

    rootAVL = insertAVLnode(&rootAVL, 10);
    insertAVLnode(&rootAVL, 20);
    insertAVLnode(&rootAVL, 30);
    insertAVLnode(&rootAVL, 40);
    insertAVLnode(&rootAVL, 50);
    insertAVLnode(&rootAVL, 60);

    printf("AVL Tree: ");
    displayInOrder(rootAVL);
    printf("\n");

    printf("Search 30 in AVL Tree: ");
    searchBST(rootAVL, 30);
    printf("\n");
    searchBST(rootAVL, 70);
    printf("\n");
    searchBST(rootAVL, 60);    
}

TreeNode* insertAVLnode(TreeNode** root, element x){
    TreeNode* p = NULL;
    TreeNode* newnode = NULL;

    p = *root;
    newnode = (TreeNode*)malloc(sizeof(TreeNode));
    newnode->key = x;
    newnode->left = NULL;
    newnode->right = NULL;

    if (p == NULL){
        *root = newnode;
        return newnode;
    }
    else{
        if (p->key > x){
            p->left = insertAVLnode(&(p->left), x);
            p = rebalance(&p);
        }
        else if (p->key < x){
            p->right = insertAVLnode(&(p->right), x);
            p = rebalance(&p);
        }
        else{
            printf("Duplicate key!\n");
            return NULL;
        }
    }
    return p;
}