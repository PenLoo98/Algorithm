#include <stdio.h>
#define MAX(a,b) ((a)>(b)?a:b)
#define MAX_DEGREE 50

typedef struct {
    int degree;
    float coef[MAX_DEGREE];
} polynomial;

polynomial addPoly(polynomial A, polynomial B);
void printPoly(polynomial P);

polynomial addPoly(polynomial A, polynomial B) {
    polynomial C; //다항식 덧셈의 결과 다항식을 저장할 polynomial 구조체 변수 선언
    int A_index = 0, B_index = 0, C_index = 0;
    int A_degree = A.degree, B_degree = B.degree;
    C.degree = MAX(A.degree, B.degree);
    
    while (A_index <= A.degree && B_index <= B.degree) {
        if (A_degree > B_degree) {
            C.coef[C_index++] = A.coef[A_index++];
            A_degree--;
        }
        else if (A_degree == B_degree) {
            C.coef[C_index++] = A.coef[A_index++] + B.coef[B_index++];
            A_degree--;
            B_degree--;
        }
        else {
            C.coef[C_index++] = B.coef[B_index++];
            B_degree--;
        }
    }
    return C; //다항식 덧셈의 결과 다항식 C를 반환
}

polynomial multPoly(polynomial A, polynomial B) {
    polynomial C;
    C.degree = A.degree + B.degree;
    for (int i = 0; i <= C.degree; i++) {
        C.coef[i] = 0;
    }
    for (int i = 0; i <= A.degree; i++) {
        for (int j = 0; j <= B.degree; j++) {
            C.coef[i + j] += A.coef[i] * B.coef[j];
        }
    }
    return C;
}


void printPoly(polynomial P) {
    for (int i = P.degree; i > 0; i--) {
        printf("%3.0fx^%d + ", P.coef[P.degree - i], i);
    }
    printf("%3.0f", P.coef[P.degree]);
}

