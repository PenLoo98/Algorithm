#include <stdio.h>

int main(){
    // 문자열 초기화 방법 2가지
    // 1. 문자열을 사용한 초기화
    // 2. 문자 배열을 사용한 초기화

    // 문자열을 사용한 초기화
    char str1[] = "String";
    char str2[] = {'S', 't', 'r', 'i', 'n', 'g', '\0'};
    char str3[] = "String\0";

    // 각 문자열을 출력
    printf("str1: %s\n",str1); 
    printf("str2: %s\n",str2);
    printf("str3: %s\n",str3);
    printf("\n");

    // 각 문자열의 문자를 출력
    for(int i=0; str1[i]; i++){
        printf("str1[%d]: %c\n",i, str1[i]);
    }
    printf("\n");

    for(int i=0; str2[i]; i++){
        printf("str2[%d]: %c\n",i, str2[i]);
    }
    printf("\n");

    for(int i=0; str3[i]; i++){
        printf("str3[%d]: %c\n",i, str3[i]);
    }
    printf("\n");
}