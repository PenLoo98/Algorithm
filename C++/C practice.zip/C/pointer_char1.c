#include <stdio.h>

int main(){
    char a[8]="abcdefg";
    char *ptr;
    ptr = "string";
    

    
    printf("ptr: %s\n", ptr);
    printf("*ptr: %c\n", *ptr);
    printf("*(ptr+1): %c\n", *(ptr+1));
    printf("*(ptr+2): %c\n", *(ptr+2));

    printf("*(ptr+7): %c\n", *(ptr+7));
    printf("*(ptr+8): %c\n", *(ptr+8));
    printf("*(ptr+9): %c\n", *(ptr+9));

    return 0;
}