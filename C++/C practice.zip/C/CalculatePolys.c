#include <stdio.h>
#include "calPoly.h"

int main(void)
{
    polynomial A = {3, {4,3,5,0}}; // 4x^3 + 3x^2 + 5
    polynomial B = {4, {3,1,0,2,1}}; // 3x^4 + x^3 + 2x + 1
    polynomial C;

    polynomial D = {1, {1,1}}; // x + 1
    polynomial E = {2, {1,2,1}}; // x^2 + 2x + 1
    polynomial F;

    C = addPoly(A, B); // C = A + B
    F = multPoly(D, E); // F = D * E

    printf("\n A(x) = "); printPoly(A);
    printf("\n B(x) = "); printPoly(B);
    printf("\n C(x) = "); printPoly(C);

    printf("\n\n D(x) = "); printPoly(D);
    printf("\n E(x) = "); printPoly(E);
    printf("\n F(x) = "); printPoly(F);

    getchar();
    return 0;
}