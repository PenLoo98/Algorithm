// https://www.acmicpc.net/problem/10171
#include <iostream>

int main(){
    std::cout << "\\    /\\" << std::endl;
    std::cout << " )  ( ')" << std::endl;
    std::cout << "(  /  )" << std::endl;
    std::cout << " \\(__)|" << std::endl;
    return 0;
}