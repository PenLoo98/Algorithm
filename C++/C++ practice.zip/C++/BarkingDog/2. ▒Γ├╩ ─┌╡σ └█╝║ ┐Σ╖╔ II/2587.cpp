// https://www.acmicpc.net/problem/2587

#include <iostream>

int main() {
    int arr[5];
    int sum = 0;
    int average, median;

    // 5개의 자연수 입력받기
    for(int i=0;i<5;i++){
        std::cin >> arr[i];
        sum += arr[i];
    }

    // 평균 구하기
    average = sum / 5;

    // 중앙값 구하기
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
            if(arr[i]>arr[j]){
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
    median = arr[2];

    std::cout << average << std::endl;
    std::cout << median << std::endl;
}