// https://www.acmicpc.net/problem/15552
#include <iostream>
using namespace std;

int main(){
    int T;
    cin >> T;

    for(int i=0; i<T; i++){
        int a, b;
        ios_base::sync_with_stdio(false);
        cin.tie(NULL);
        cin >> a >> b;
        cout << a+b << "\n";
    }
    return 0;
}