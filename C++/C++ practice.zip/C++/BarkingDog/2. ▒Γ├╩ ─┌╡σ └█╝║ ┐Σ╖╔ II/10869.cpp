// https://www.acmicpc.net/problem/10869

#include <iostream>
using namespace std;

int main(){
    int A,B;
    
    cin >> A >> B;
    cout << A+B << endl;
    cout << A-B << endl;
    cout << A*B << endl;
    cout << A/B << endl;
    cout << A%B << endl;

    return 0;
}