// https://www.acmicpc.net/problem/1000

#include <iostream>

int main(){
    int A, B;
    std::cin >> A >> B;
    std::cout << A+B << std::endl;
    return 0;
}