// https://www.acmicpc.net/problem/10093

#include <iostream>

int main(){
    long long a, b;
    std::cin >> a >> b;

    // a가 b보다 크면 두 수를 바꿈
    if(a > b){
        long long temp = a;
        a = b;
        b = temp;
    }

    // a와 b가 같으면 0을 출력
    if(a == b){
        std::cout << 0 << std::endl;
    }
    // a와 b가 다르면 b - a - 1을 출력
    else{
        std::cout << b - a - 1 << std::endl;
        for(long long i=a+1;i<b;i++){
            std::cout << i << " ";
        }
    }

    return 0;
}