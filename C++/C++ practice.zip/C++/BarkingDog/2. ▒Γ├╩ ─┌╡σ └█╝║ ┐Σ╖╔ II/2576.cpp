// https://www.acmicpc.net/problem/2576

#include <iostream>

int main(){
    int arr[7];
    int sum = 0;
    int min;

    // 7번 자연수 입력받기
    for(int i = 0; i < 7; i++){
        std::cin >> arr[i];
        if(arr[i] % 2 == 1){
            sum += arr[i];

            // 최솟값 구하기
            if(i == 0){
                min = arr[i];
            }
            else if(min > arr[i]) min = arr[i];
        }
    }

    // 홀수가 없을 경우
    if(sum == 0){
        std::cout << -1 << std::endl;
    }

    // 홀수가 있을 경우
    else{
        std::cout << sum << std::endl;
        std::cout << min << std::endl;
    }
}