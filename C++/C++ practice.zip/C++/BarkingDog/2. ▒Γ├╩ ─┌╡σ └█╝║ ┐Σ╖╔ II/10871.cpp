// https://www.acmicpc.net/problem/10871

#include <iostream>

int main(){
    int N, X;
    std::cin >> N >> X;

    int* arr = new int[N];
    for(int i = 0; i < N; i++){
        std::cin >> arr[i];
    }

    for(int i=0; i<N; i++){
        if(arr[i] < X) {
            std::cout<<arr[i]<<" ";
        }
        
    }
    std::cout<<std::endl;
    return 0;
}
