// https://www.acmicpc.net/problem/9498

#include <iostream>

int main(){
    int score;

    std::cin >> score;
    

    if (100 >= score && score>= 90){
        std::cout << "A" << std::endl;
        return 0;
    }
    if (90 > score && score >= 80){
        std::cout << "B" << std::endl;
        return 0;
    }
    if (80 > score &&  score >= 70){
        std::cout << "C" << std::endl;
        return 0;
    }
    if (70 > score &&  score >= 60){
        std::cout << "D" << std::endl;
        return 0;
    }
    if (60 > score &&  score >= 0){
        std::cout << "F" << std::endl;
        return 0;
    }
}