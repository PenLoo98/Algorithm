// https://www.acmicpc.net/problem/2480

#include <iostream>

int main(){
    int A, B, C;
    std::cin >> A >> B >> C;

    if (A == B && B == C){
        std::cout << 10000 + A*1000 << std::endl;
        return 0;
    }

    else if (A==B){
        std::cout << 1000 + A*100 << std::endl;
        return 0;
    }
    else if (B==C){
        std::cout << 1000 + B*100 << std::endl;
        return 0;
    }
    else if (A==C){
        std::cout << 1000 + A*100 << std::endl;
        return 0;
    }
    else{
        if (A > B && A > C){
            std::cout << A*100 << std::endl;
            return 0;
        }
        else if (B > A && B > C){
            std::cout << B*100 << std::endl;
            return 0;
        }
        else if (C > A && C > B){
            std::cout << C*100 << std::endl;
            return 0;
        }
    }
}