// https://www.acmicpc.net/problem/2309

#include <iostream>

int main(){
    int arr[9];
    int sum = 0;

    // 9 난쟁이 키를 입력받음
    for(int i=0;i<9;i++){
        std::cin >> arr[i];
        sum += arr[i];
    }

    // 9 난쟁이 키를 오름차순으로 정렬
    for(int i=0;i<9;i++){
        for(int j=i+1;j<9;j++){
            if(arr[i] > arr[j]){
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }

    // 9 난쟁이 키의 합에서 2 난쟁이 키를 뺀 값이 100이면
    // 2 난쟁이 키를 제외한 7 난쟁이 키를 출력
    for(int i=0;i<9;i++){
        for(int j=i+1;j<9;j++){
            if(sum - arr[i] - arr[j] == 100){
                for(int k=0;k<9;k++){
                    if(k != i && k != j){
                        std::cout << arr[k] << std::endl;
                    }
                }
                return 0;
            }
        }
    }

    return 0;
}