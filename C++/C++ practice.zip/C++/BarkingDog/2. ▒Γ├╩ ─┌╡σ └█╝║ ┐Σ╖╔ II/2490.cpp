// https://www.acmicpc.net/problem/2490

#include <iostream>

int main(){
    int arr[4];
    for(int i = 0; i < 3; i++){
        std::cin >> arr[0] >> arr[1] >> arr[2] >> arr[3];
        int sum = arr[0] + arr[1] + arr[2] + arr[3];

        switch(sum){
            case(0): std::cout << "D" << std::endl; break;
            case(1): std::cout << "C" << std::endl; break;
            case(2): std::cout << "B" << std::endl; break;
            case(3): std::cout << "A" << std::endl; break;
            case(4): std::cout << "E" << std::endl; break;
        }
    }
    return 0;
}