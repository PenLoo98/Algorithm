﻿//과제: 원형 큐를 이용하여 큐의 크기를 동적으로 할당하고, 큐의 원소를 출력하는 연산을 구현하시오.
//배열이 풀일때 큐의 크기를 2배로 늘리고, 큐의 원소를 출력하는 연산을 구현하시오.
// front 삭제만, rear는 삽입만 가능

#include <stdio.h>
#include <stdlib.h>

#define QUEUE_SIZE 10

int* queue;
int front;
int rear;
int size;

int isEmpty() {
    if (front == rear) return 1;
    else return 0;
}

// 큐가 포화 상태인지 확인
int isFull() {
    if (front == (rear + 1) % size) return 1;
    else return 0;
}

int queueSize() {
    if (isEmpty()) return 0;
    else return (rear - front + size) % size + 1;
}

// 큐에 원소를 삽입
void enqueue(int item) {
    if (isFull()) {
        printf("Full QUEUE\n");
        int* newQueue = (int*)malloc(size * 2 * sizeof(int));
        int i, j;
        for (i = front, j = 0; i != rear; i = (i + 1) % size, j++) {
            newQueue[j] = queue[i];
        }
        newQueue[j] = queue[i];
        front = 0;
        rear = j;
        size *= 2;
        free(queue);
        queue = newQueue;
    }
    if (isEmpty()) {
        printf("Queue is Empty!!\n");
    }

    rear = (rear + 1) % size;
    queue[rear] = item;
}

// 큐에서 원소를 삭제
int dequeue() {
    // 큐가 공백 상태인 경우
    if (front == rear) {
        front = 0;
        rear = 0;
    }
    else {
        front = (front + 1) % size;
    }
    return 0;
}

// 큐의 원소를 출력
void printQueue() {
    // 큐가 공백 상태인 경우
    if (isEmpty()) {
        printf("Queue is empty.\n");
        return;
    }
    printf("Queue: ");
    int i;
    for (i = front + 1; i != rear; i = (i + 1) % size) {
        printf("%d ", queue[i]);
    }
    printf("%d\n", queue[i]);
}

int main() {
    queue = (int*)malloc(QUEUE_SIZE * sizeof(int));
    size = QUEUE_SIZE;
    front = 0;
    rear = 0;

    // 1~8 숫자 대입
    for (int i = 1; i <= 8; i++)
    {
        enqueue(i);
    }
    printQueue();

    //2회 삭제
    for (int i = 1; i <= 2; i++) {
        dequeue();
        printQueue();
    }

    // 9~14 숫자 대입
    for (int i = 9; i <= 14; i++)
    {
        enqueue(i);
    }
    printQueue();

    // 메모리 반환
    free(queue);
    return 0;
}