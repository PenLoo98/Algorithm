#include <iostream>
using namespace std;

int main(){
    char word[20];
    cout << "Enter a character: ";
    cin.getline(word, 20, '\n');
    cout << "The character you entered is: " << word << endl;
    return 0;
};