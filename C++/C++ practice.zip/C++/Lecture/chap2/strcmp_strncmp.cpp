//C++일 경우
#include <iostream>
#include <cstring> 

// C인 경우 필요한 헤더파일
//#include <stdio.h> 
//#include <string.h>

int main()
{
    char s1[4] = "aaa";
    char s2[4] = "aaa";
    char s3[4] = "aab";

    // 같으면 0, 다르면 0이 아닌 값을 반환
    int compare1 = strcmp(s1, s2);//strcmp 입력된 문자열 비교
    int compare2 = strcmp(s1, s3);
    int compare3 = strcmp(s3, s1);
    
    // 같으면 0, 다르면 0이 아닌 값을 반환
    int compare4 = strncmp(s1, s3, 2);//strncmp 입력된 문자열을 2번째까지 비교
    int compare5 = strncmp(s3, s1, 2);
    int compare6 = strncmp(s3, s1, 3);
    
     //strcmp
    printf("s1 vs s2 : %d\n", compare1); //0
    printf("s1 vs s3 : %d\n", compare2); //음수
    printf("s3 vs s1 : %d\n", compare3); //양수

    if (!strcmp(s1, s2))printf("s1==s2\n");
    if (strcmp(s1, s3))printf("s1!=s3\n");

    //strncmp
    printf("s1 vs s3 2번째까지 비교결과 : %d\n", compare4); 
    printf("s3 vs s1 2번째까지 비교결과 : %d\n", compare5);
    printf("s3 vs s1 3번째까지 비교결과 : %d\n", compare6); 

    if (!strncmp(s1, s2, 2))printf("s1과 s2은 2째 자리까지 같습니다.\n");
    if (!strncmp(s1, s3, 2))printf("s1과 s3은 2째 자리까지 같습니다.\n");

    if (!strncmp(s3, s1, 3))printf("s3과 s1은 3째 자리까지 같습니다.\n");
    else {printf("s3과 s1은 3째자리까지 비교했을 때 다릅니다.\n");};
    

    return 0;
}