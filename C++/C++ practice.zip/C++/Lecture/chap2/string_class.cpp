#include <iostream>
#include <string>
using namespace std;

int main(){
    string word;
    cout << "Enter a character: ";
    getline(cin, word, '\n');
    cout << "The character you entered is: " << word << endl;
    return 0;
}