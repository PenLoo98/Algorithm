#include <iostream>
using namespace std;

int main(){
    char word[20];
    cout << "Enter a character: ";
    cin >> word;
    cout << "The character you entered is: " << word << endl;
    return 0;
}