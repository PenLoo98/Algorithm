#include <iostream>
#include <fstream>
#include <string>
#include <stack>

using namespace std;

// 요구사항
// 1. 타입을 구분해서 int - double, double - int 연산을 가능하게 하라.
// 2. 텍스트 형식 다항식 연산을 가능하게 하라.
// 3. 추상화 클래스와 operator 연산을 오버라이딩 할 것.
// 4. 텍스트 파일에 결과를 저장하라.
// 5. 예외처리를 할 것.
// 6. 보고서 작성할 시행착오 기록할 것.

// 예외처리 클래스
class Exceptions {
    // ineNo는 에러가 발생한 줄 번호, msg는 에러 메시지
    int lineNo;
    string msg;

public:
    // 생성자,소멸자
    Exceptions(int n, string m) {
        lineNo = n;
        msg = m;
    };
    ~Exceptions() = default;

    // 에러메시지 출력 함수
    void printException() {
        cout << msg << ": Line " << lineNo << endl;
        // 에러메시지를 출력하고 프로그램 종료
        std::exit(true);
    }
};

// 0으로 나누는 예외처리 클래스
class DivideByZeroException : public Exceptions {
public:
    // msg값은 이미 입력하였고, lineNo만 입력하면 실행됌
    DivideByZeroException(int lineNo, string msg = "Divide by zero exception") : Exceptions(lineNo, msg) {};
    ~DivideByZeroException() = default;
};

// 잘못된 입력 예외처리 클래스
class InvalidInputException : public Exceptions {
public:
    // msg값은 이미 입력하였고, lineNo만 입력하면 실행됌
    InvalidInputException(int lineNo, string msg = "Invalid input exception") : Exceptions(lineNo, msg) {};
    ~InvalidInputException() = default;
};

// 기본 계산기 클래스
template <typename T1, typename T2>
class VirtualCalculator {
public:

    // operator에 2개의 입력값을 주기 위한 구조체
    struct Operands {
        T1 operand1;
        T2 operand2;
    };

    // 생성자,소멸자
    VirtualCalculator() = default;
    ~VirtualCalculator() = default;

    // 사칙 연산자 가상함수
    virtual double operator+(Operands plus) { return 0; };
    virtual double operator-(Operands minus) { return 0; };
    virtual double operator*(Operands multiply) { return 0; };
    virtual double operator/(Operands divide) { return 0; };

};

// 계산기 클래스 (템플릿)
template <typename T1, typename T2>
class Calculator : public VirtualCalculator<T1, T2> {
public:

    // 다항식의 계산을 위한 스택
    // 숫자를 저장하는 스택 operands, 연산자를 저장하는 스택 operators
    stack<double> operands;
    stack<char> operators;

    // operator에 2개의 입력값을 주기 위한 구조체
    struct Operands {
        T1 operand1;
        T2 operand2;
    };

    // 생성자,소멸자
    Calculator() = default;
    ~Calculator() = default;

    // 사칙 연산자 오버라이드
    double operator+(Operands& inputs) {
        return (double)inputs.operand1 + (double)inputs.operand2;
    };
    double operator-(Operands& inputs) {
        return (double)inputs.operand1 - (double)inputs.operand2;
    };
    double operator*(Operands& inputs) {
        return (double)inputs.operand1 * (double)inputs.operand2;
    };
    double operator/(Operands& inputs) {
        // 0으로 나누는 예외처리
        try {
            if (inputs.operand2 == 0) {
                throw DivideByZeroException(__LINE__);
            }
            return (double)inputs.operand1 / (double)inputs.operand2;
        }
        // 예외 메시지 출력 후 프로그램 종료
        catch (DivideByZeroException& e) {
            e.printException();
        }
    };

    // 사칙연산자 문자인지 확인
    bool isOper3(char oper) {
        if (oper == '*' || oper == '/' || oper == '+') {
            return true;
        }
        else return false;
    }

    // 공백 문자인지 확인
    bool isSpace(char ch) {
        return (ch == ' ' || ch == '\t' || ch == '\n' || ch == '\r' || ch == '\f' || ch == '\v');
    }

    // 아스키코드로 숫자인지 확인
    bool isNumber(char ch) {
        return (ch >= '0' && ch <= '9');
    }

    // 연산이 필요한 경우 확인
    // cal은 계산기 객체, ch는 현재 문자
    bool needCalculate(Calculator& cal, char ch) {
        // [operators에 연산자가 있다] AND [스택 맨위 연산자가 '('가 아니다] AND [현재 연산자가 '+','-' OR 스택 맨위 연산자가 ''*','/']
        // +,-가 들어왔는데 스택 맨위가 * or /이면 계산 필요
        if (!cal.operators.empty() && cal.operators.top() != '(' && ((ch == '+' || ch == '-') || (cal.operators.top() == '*' || cal.operators.top() == '/')))
        {
            return true;
        }
        else {
            return false;
        }
    }

    // 문자열 다항식 계산 멤버함수
    double PolyTextCalculate(Calculator& cal,string& polynomial) {
        struct Calculator<double, double>::Operands inputs;

        try {
            for (int i = 0; i < polynomial.length(); i++) {
                char ch = polynomial[i];

                // 공백문자 확인
                if (isSpace(ch)) {
                    continue;
                }

                // 숫자 확인
                else if (isNumber(ch) || ch == '.') {
                    int j = i;
                    // 실수 처리
                    while (j < polynomial.length() && (isNumber(polynomial[j]) || polynomial[j] == '.')) {
                        j++;
                    }
                    string operandStr = polynomial.substr(i, j - i); // 실수 string을 저장
                    double operand = stod(operandStr); // 정수 string을 double로 변환
                    cal.operands.push(operand);
                    i = j - 1; // 실수 소숫점 이후부터 다시 확인
                }

                // 여는 괄호 확인
                else if (ch == '(') {
                    cal.operators.push(ch);
                }

                // -연산자 처리
                else if (ch == '-') {
                    // 음수 처리를 위해 0과의 차이를 계산
                    if (i == 0 || polynomial[i - 1] == '(' || cal.isOper3(polynomial[i - 1])) {
                        double zero = 0.0;
                        cal.operands.push(zero);
                        cal.operators.push(ch);
                    }
                    // 음수가 아닌 빼기 연산자인 경우
                    else {
                        // 연산이 필요한 경우 연산
                        while (needCalculate(cal,ch))
                        {
                            char op = cal.operators.top();
                            cal.operators.pop();

                            inputs.operand2 = cal.operands.top();
                            cal.operands.pop();
                            inputs.operand1 = cal.operands.top();
                            cal.operands.pop();

                            if (op == '+') {
                                cal.operands.push(cal.operator+(inputs));
                            }
                            else if (op == '-') {
                                cal.operands.push(cal.operator-(inputs));
                            }
                            else if (op == '*') {
                                cal.operands.push(cal.operator*(inputs));
                            }
                            else if (op == '/') {
                                cal.operands.push(cal.operator/(inputs));
                            }
                        }

                        cal.operators.push(ch);
                    }
                }

                // 닫는 괄호 확인
                else if (ch == ')') {
                    // 괄호()가 완성되어 ()내부 연산을 함
                    while (!cal.operators.empty() && cal.operators.top() != '(') {
                        char op = cal.operators.top();
                        cal.operators.pop();

                        inputs.operand2 = cal.operands.top();
                        cal.operands.pop();
                        inputs.operand1 = cal.operands.top();
                        cal.operands.pop();

                        if (op == '+') {
                            cal.operands.push(cal.operator+(inputs));
                        }
                        else if (op == '-') {
                            cal.operands.push(cal.operator-(inputs));
                        }
                        else if (op == '*') {
                            cal.operands.push(cal.operator*(inputs));
                        }
                        else if (op == '/') {
                            cal.operands.push(cal.operator/(inputs));
                        }
                    }
                    // ()안의 값을 연산 후 남아있는 '('를 pop
                    if (!cal.operators.empty() && cal.operators.top() == '(') {
                        cal.operators.pop();
                    }
                }
                // 사칙연산자 확인 +,*,/만 (-는 따로 처리)
                else if (cal.isOper3(ch)) {
                    // 연속된 연산자 예외처리 (++,--, **, //, +/,,-*)
                    // 연산자가 마지막이 아니면서 다음 문자가 연산자인 경우 예외처리
                    if (ch == '+' && (i + 1 < polynomial.length() && (polynomial[i + 1] == '+' || polynomial[i + 1] == '-'|| polynomial[i + 1] == '*'|| polynomial[i + 1] == '/') )) {
                        throw InvalidInputException(__LINE__);
                    }
                    else if (ch == '-' && (i + 1 < polynomial.length() && (polynomial[i + 1] == '+' || polynomial[i + 1] == '-' || polynomial[i + 1] == '*' || polynomial[i + 1] == '/') )) {
                        throw InvalidInputException(__LINE__);
                    }
                    else if (ch == '*' && (i + 1 < polynomial.length() && (polynomial[i + 1] == '+' || polynomial[i + 1] == '*' || polynomial[i + 1] == '/') )) {
                        throw InvalidInputException(__LINE__);
                    }
                    else if (ch == '/' && (i + 1 < polynomial.length() && (polynomial[i + 1] == '+' || polynomial[i + 1] == '*' || polynomial[i + 1] == '/') )) {
                        throw InvalidInputException(__LINE__);
                    }

                    // 연산이 필요한 경우 연산
                    while (needCalculate(cal,ch))
                    {
                        char op = cal.operators.top();
                        cal.operators.pop();

                        inputs.operand2 = cal.operands.top();
                        cal.operands.pop();
                        inputs.operand1 = cal.operands.top();
                        cal.operands.pop();

                        if (op == '+') {
                            cal.operands.push(cal.operator+(inputs));
                        }
                        else if (op == '-') {
                            cal.operands.push(cal.operator-(inputs));
                        }
                        else if (op == '*') {
                            cal.operands.push(cal.operator*(inputs));
                        }
                        else if (op == '/') {
                            cal.operands.push(cal.operator/(inputs));
                        }
                    }

                    cal.operators.push(ch);
                }
                // 그 외의 문자는 예외처리
                else {
                    throw InvalidInputException(__LINE__);
                }
            }
        }
        // 예외 메시지 출력 후 프로그램 종료
        catch (InvalidInputException& e) {
            e.printException();
        }

        // 입력된 문자열을 모두 확인한 후 스택에 남은 연산자를 처리
        while (!cal.operators.empty()) {
            char op = cal.operators.top();
            cal.operators.pop();

            inputs.operand2 = cal.operands.top();
            cal.operands.pop();
            inputs.operand1 = cal.operands.top();
            cal.operands.pop();

            if (op == '+') {
                cal.operands.push(cal.operator+(inputs));
            }
            else if (op == '-') {
                cal.operands.push(cal.operator-(inputs));
            }
            else if (op == '*') {
                cal.operands.push(cal.operator*(inputs));
            }
            else if (op == '/') {
                cal.operands.push(cal.operator/(inputs));
            }
        }

        return cal.operands.top();
    }
};

// 텍스트 파일 저장
void saveTxt(double result) {
    ofstream outputFile("result.txt");
    outputFile << "Calculation result: " << result << endl;
    outputFile.close();
    cout << "Save the result to a result.txt file" << endl;
}

int main() {
    // 다항식 문자열 입력 받기
    string polynomial;
    cout << "Enter a polynomial: ";
    getline(cin, polynomial);

    // 테스트 케이스 
    // string polynomial = "0/5";
    // string polynomial = "5/0";
    // string polynomial = "(1+2/3+1)";
    // string polynomial = "(1+4/3)*2+3.5";
    // string polynomial = "(-1-2.5)*3"
    // string polynomial = "-(-1-2.5)*3"
    // string polynomial = "-2*(1.5+2/4)-(3+2.5*3)"
    // string polynomial = "-2*(1.5+2/4)-1*(3+2.5*3)"
    // string polynomial = "2*(1.5+2/4)-1*(3+2.5*3)"
    // string polynomial = "(2*(1.5+2/4)-(3+2.5*3))+8.5"

    // 계산 수행
    Calculator<double, double> cal;
    double result = cal.PolyTextCalculate(cal,polynomial);

    // 결과 출력
    std::cout << "Calculation result: " << result << std::endl;

    // 계산 결과를 txt파일에 저장
    saveTxt(result);

    return 0;
}