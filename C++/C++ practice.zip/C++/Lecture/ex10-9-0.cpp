#include<iostream>
using namespace std;

int main(){
    int array1[3] = {1, 2, 3}; 
    for(int i=0; i<3; i++){
        cout << array1[i] << " ";
    }

    int sz;
    cout << "Enter the size of the array2: " << endl;
    cin >> sz;

    int* array2 = new int[sz];
    for(int i=0; i<sz; i++){
        array2[i] = i;
        cout << array2[i] << endl;
    }
    delete[] array2;

    return 0;
}