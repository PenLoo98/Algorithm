// 다음 소스 코드를 템플릿을 이용하여 동일한 결과를 출력하도록 프로그램을 변경하라 (변경된 프로그래만 제출할 것) [40점].
// <변경 전>
#include <iostream>
#include <string>
using namespace std;

class Shape {
public:
	void paint() {
		draw();
	}
	virtual void draw() {
		cout << "Shape::draw() called" << endl;
	}
};

class Circle : public Shape {
public:
	virtual void draw() {
		cout << "Circle::draw() called" << endl;
	}
};

class Rectangle : public Shape {
public:
	virtual void draw() {
		cout << "Rectangle::draw() called" << endl;
	}
};

class Triangle : public Shape {
public:
	virtual void draw() {
		cout << "Triangle::draw() called" << endl;
	}
};

int main() {

	string shape;
	cout << "도형을 입력하세요>>";
	getline(cin, shape);

	if (shape == "Circle")
	{
		Shape *pShape1 = new Circle();
		pShape1->paint();
		delete pShape1;
	}
	else if (shape == "Rectangle")
	{
		Shape *pShape2 = new Rectangle();
		pShape2->paint();
		delete pShape2;
	}
	else if (shape == "Triangle")
	{
		Shape *pShape3 = new Triangle();
		pShape3->paint();
		delete pShape3;
	}
	else
		cout << "도형을 잘못 입력했습니다. 다시 입력 바랍니다.";
}

