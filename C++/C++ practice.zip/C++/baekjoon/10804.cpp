﻿// https://www.acmicpc.net/problem/10804

#include <iostream>
using namespace std;

int main() {
    // 1~20까지 배열에 넣기
    int arr[21];
    for (int i = 0; i <= 20; i++) {
        arr[i] = i;
    }

    // 10번 입력
    for (int i = 0; i < 10; i++) {
        int a, b;
        cin >> a >> b;
        // a~b까지 뒤집기
        for (int i = 0; i < (b - a + 1) / 2; i++) {
            int temp = arr[i+a];
            arr[i + a] = arr[b-i];
            arr[b - i] = temp;
        }
    }

    // 출력 
    for (int i = 1; i <= 20; i++) {
        cout << arr[i] << " ";
    }
    return 0;
}