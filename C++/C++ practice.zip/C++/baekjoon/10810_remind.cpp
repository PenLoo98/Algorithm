//https://www.acmicpc.net/problem/10810

#include <iostream>
using namespace std;

int main(){
    // N,M 입력
    int N,M;
    cin >> N >> M;

    // N개 바구니 생성
    int *list = new int[N+1];
    for(int i=1;i<=N;i++){
        list[i] = 0;
    }

    // M번공을 입력
    for (int z=0;z<M;z++){
        int start,end,ball;
        cin >> start >> end >> ball;

        for (start;start<=end;start++){
            list[start]=ball;
        }
    }

    // N 바구니 결과 출력
    for(int i=1;i<=N;i++){
        cout << list[i] << ' ';
    }

    cout << endl;

    // 마무리
    delete[] list;
    return 0;
}